package com.example.nearbyplaces.common

import com.example.nearbyplaces.model.Results
import com.example.nearbyplaces.network.MyGoogleAPIService
import com.example.nearbyplaces.network.RetrofitClient
import com.example.nearbyplaces.network.RetrofitScalarsClient

object Common {
    private val GOOGLE_API_URL = "https://maps.googleapis.com/"

    var currentResult: Results? = null

    val googleAPIService: MyGoogleAPIService
        get() = RetrofitClient.getClient(GOOGLE_API_URL).create(MyGoogleAPIService::class.java)

    val googleAPIServiceScalars: MyGoogleAPIService
        get() = RetrofitScalarsClient.getClient(
            "https://google-maps28.p.rapidapi.com/"
        ).create(MyGoogleAPIService::class.java)
}
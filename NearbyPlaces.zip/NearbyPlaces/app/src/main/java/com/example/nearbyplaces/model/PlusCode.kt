package com.example.nearbyplaces.model

class PlusCode {
    var compound_code: String? = null
    var global_code: String? = null
}

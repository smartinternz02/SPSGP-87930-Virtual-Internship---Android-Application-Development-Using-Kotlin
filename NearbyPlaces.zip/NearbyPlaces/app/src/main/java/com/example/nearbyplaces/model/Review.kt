package com.example.nearbyplaces.model

class Review {
    val author_name: String? = null
    val author_url: String? = null
    val language: String? = null
    val original_language: String? = null
    val profile_photo_url: String? = null
    val rating = 0
    val relative_time_description: String? = null
    val text: String? = null
    val time = 0
    val translated = false
}
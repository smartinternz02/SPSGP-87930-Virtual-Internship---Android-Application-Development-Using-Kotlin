package com.example.nearbyplaces.model

class OpeningHours {
    var open_now: Boolean = false
}
package com.example.nearbyplaces.model

class Photo {
    var height: Int = 0
    var width: Int = 0
    var html_attributions: Array<String>? = null
    var photo_reference: String? = null
}
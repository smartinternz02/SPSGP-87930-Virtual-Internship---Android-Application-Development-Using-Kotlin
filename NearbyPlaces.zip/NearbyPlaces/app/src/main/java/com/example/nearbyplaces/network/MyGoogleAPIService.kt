package com.example.nearbyplaces.network

import com.example.nearbyplaces.model.MyPlaces
import com.example.nearbyplaces.model.PlaceDetail
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url

interface MyGoogleAPIService {
    @GET
    fun getNearbyPlaces(@Url url: String): Call<MyPlaces>

    @GET
    fun getDetailPlace(@Url url: String): Call<PlaceDetail>

    @GET("maps/api/directions/json")
    fun getDirections(@Query("destination") destination: String, @Query("origin") origin: String): Call<String>
}
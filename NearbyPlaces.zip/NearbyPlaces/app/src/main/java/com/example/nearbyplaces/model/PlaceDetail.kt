package com.example.nearbyplaces.model

class PlaceDetail {
    val html_attributions: List<Object>? = null
    val result: Result? = null
    val status: String? = null
}

class Result {
    val address_components: List<AddressComponent>? = null
    val adr_address: String? = null
    val business_status: String? = null
    val formatted_address: String? = null
    val formatted_phone_number: String? = null
    val geometry: Geometry? = null
    val icon: String? = null
    val icon_background_color: String? = null
    val icon_mask_base_uri: String? = null
    val international_phone_number: String? = null
    val name: String? = null
    val photos: List<Photo>? = null
    val plus_code: PlusCode? = null
    val price_level = 0
    val rating = 0.0
    val reference: String? = null
    val reviews: List<Review>? = null
    val types: List<String>? = null
    val url: String? = null
    val user_ratings_total = 0
    val utc_offset = 0
    val vicinity: String? = null
    val website: String? = null
}
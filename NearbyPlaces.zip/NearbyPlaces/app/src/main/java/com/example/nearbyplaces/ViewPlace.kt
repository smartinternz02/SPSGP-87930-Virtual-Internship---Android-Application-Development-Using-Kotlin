package com.example.nearbyplaces

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.nearbyplaces.common.Common
import com.example.nearbyplaces.databinding.ActivityViewPlaceBinding
import com.example.nearbyplaces.model.PlaceDetail
import com.example.nearbyplaces.network.MyGoogleAPIService
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewPlace : AppCompatActivity() {

    private lateinit var binding: ActivityViewPlaceBinding

    internal lateinit var mService: MyGoogleAPIService
    var mPlace: PlaceDetail? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewPlaceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Init Service
        mService = Common.googleAPIService

        binding.apply {
            //Set empty for all text views
            placeName.text = ""
            placeAddress.text = ""
            placeOpenHour.text = ""

            btnShowMap.setOnClickListener {
                //Open map intent to view
                val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse(mPlace!!.result!!.url))
                startActivity(mapIntent)
            }

            btnViewDirections.setOnClickListener {
                val viewDirections = Intent(this@ViewPlace, ViewDirections::class.java)
                startActivity(viewDirections)
            }

            //Load photo of place
            if ((Common.currentResult!!.photos != null) && Common.currentResult!!.photos!!.size > 0) {
                Picasso.with(applicationContext)
                    .load(getPhotoOfPlace(Common.currentResult!!.photos!![0].photo_reference!!, 1000))
                    .into(photo)
            }

            //Load rating
            ratingBar.rating = Common.currentResult!!.rating.toFloat()

            //Build URL request base on place details
            val url = getPlaceDetailUrl(Common.currentResult!!.place_id.toString())

            mService.getDetailPlace(url)
                .enqueue(object: Callback<PlaceDetail> {
                    override fun onResponse(call: Call<PlaceDetail>, response: Response<PlaceDetail>) {
                        mPlace = response!!.body()!!
                        if (response!!.isSuccessful) {
                            binding.apply {
                                placeName.text = mPlace!!.result!!.name
                                placeAddress.text = mPlace!!.result!!.formatted_address
                                placeOpenHour.text = mPlace!!.result!!.business_status
                            }
                        }
                    }

                    override fun onFailure(call: Call<PlaceDetail>, t: Throwable) {
                        Toast.makeText(baseContext, "" + t!!.message, Toast.LENGTH_SHORT).show()
                    }
                })
        }
    }

    private fun getPlaceDetailUrl(place_id: String): String {
        val url = StringBuilder("https://google-maps28.p.rapidapi.com/maps/api/place/details/json")
        url.append("?fields=all")
        url.append("&place_id=$place_id")
        url.append("&rapidapi-key=4199775752msha3dab9e47ecb5a3p1af4d5jsn4600860b10e5")
        return url.toString()
    }

    private fun getPhotoOfPlace(photo_reference: String, max_width: Int): String {
        val url = StringBuilder("https://google-maps28.p.rapidapi.com/maps/api/place/photo")
        url.append("?photo_reference=$photo_reference")
        url.append("&maxwidth=$max_width")
        url.append("&rapidapi-key=4199775752msha3dab9e47ecb5a3p1af4d5jsn4600860b10e5")
        return url.toString()
    }
}
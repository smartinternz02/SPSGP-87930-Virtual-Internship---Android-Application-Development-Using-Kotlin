package com.example.nearbyplaces.model

class Results {
    var business_status: String? = null
    var geometry: Geometry? = null
    var icon: String? = null
    var icon_background_color: String? = null
    var icon_mask_base_uri: String? = null
    var name: String? = null
    var opening_hours: OpeningHours? = null
    var photos: ArrayList<Photo>? = null
    var place_id: String? = null
    var plus_code: PlusCode? = null
    var rating = 0.0
    var reference: String? = null
    var scope: String? = null
    var types: ArrayList<String>? = null
    var user_ratings_total = 0
    var vicinity: String? = null
    var permanently_closed = false
}
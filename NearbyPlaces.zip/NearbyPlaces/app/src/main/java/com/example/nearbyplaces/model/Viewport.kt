package com.example.nearbyplaces.model

class Viewport {
    var northeast: Northeast? = null
    var southwest: Southwest? = null
}
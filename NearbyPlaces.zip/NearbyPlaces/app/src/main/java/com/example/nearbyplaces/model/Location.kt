package com.example.nearbyplaces.model

class Location {
    var lat: Double = 0.0
    var lng: Double = 0.0
}
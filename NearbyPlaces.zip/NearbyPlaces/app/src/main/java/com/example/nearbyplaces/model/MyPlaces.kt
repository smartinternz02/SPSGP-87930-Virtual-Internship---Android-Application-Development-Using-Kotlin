package com.example.nearbyplaces.model

class MyPlaces {
    var html_attributions: Array<Object>? = null
    var status: String? = null
    var next_page_token: String? = null
    var results: Array<Results>? = null
}